import { auth } from "@/lib/auth";
import { NextResponse } from "next/server";
export async function requireAdmin() { const session = await auth(); if (!session || (session.user as { role?: string }).role !== "admin") return { error: NextResponse.json({ error: "Unauthorized" }, { status: 401 }), session: null }; return { error: null, session }; }
